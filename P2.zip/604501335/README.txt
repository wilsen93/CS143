Name: Wilsen Kosasih
UID: 604501335

Other than the part of the code marked with //IMPLEMENT ME,
The change made is an addition of a function called “rowtobytes” to “CS143Util.scala”

The function takes in an object of row type and return an array of bytes.
It is a modification of “getBytesFromList” function.