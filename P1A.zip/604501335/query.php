<html>
<head><title>CS143 Project 1A</title></head>
<body>


<h1> Movie/Actor/Director Database </h1>
Type SQL Query below</tt><br />

<p>
<form action="query.php" method="GET">
	<textarea name="query" cols="60" rows="8"><?php print htmlspecialchars($_GET['query']);?></textarea><br />
	<input type="submit" value="Submit" />
</form>
</p>

<p><small>Note: tables and fields are case sensitive. </small>
</p>

<?php
		$db_connection = mysql_connect("localhost","cs143","");
		if ($db_connection->connect_error) {
    		die("Connection failed: " . $db_connection->connect_error);
		} 
		mysql_select_db("CS143", $db_connection);
		
		$userquery=$_GET["query"];
		$rs=mysql_query($userquery, $db_connection);
		
?>

<html><body><table border=1>
<?php
	
	$i = 0;
	while($i < mysql_num_fields($rs))
	{
		$field = mysql_fetch_field($rs, $i);
		print '<td>';
		print $field->name;
		print '</td>';
		$i = $i + 1;
	}
	
	$i = 0;
	while($row = mysql_fetch_row($rs))
	{
		print '<tr>';
		$j = 0;
		while($j < count($row))
		{
			if(current($row)!=NULL)
				print '<td>'. current($row). '</td>';
			else
				print '<td> N/A </td>';
				
			next($row);
			$j = $j + 1;
		}
		print '</tr>';
		$i = $i + 1;
	}
?>
	</table></body></html>
</body>
</html>
