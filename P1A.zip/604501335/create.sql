CREATE TABLE Movie(
       -- Constraint: Every Movie must have an id
       id int NOT NULL,
       title varchar(100),
       year int,
       rating varchar(10),
       company varchar(50),
       PRIMARY KEY (id),
       -- Constrain: Every Movie must have a non-empty string
       CHECK(title IS NOT NULL AND LENGTH(title)>0)
) ENGINE=INNODB;

CREATE TABLE Actor(
       -- Constraint: Every Actor must have an id
       id int NOT NULL,
       last varchar(20),
       first varchar(20),
       sex varchar(6),
       dob date,
       dod date,
       PRIMARY KEY (id),
       -- Constraint: Every Actor must have a non-empty first name
       CHECK(first IS NOT NULL AND LENGTH(first)>0),
       -- Constraint: Every Actor Must have a dob
       CHECK(dob IS NOT NULL)
) ENGINE=INNODB;

CREATE TABLE Sales(
       mid int NOT NULL,
       ticketsSold int,
       totalIncome int,
       FOREIGN KEY (mid) references Movie(id),
       -- Constraint: Ticket sale cannot be negative
       CHECK(ticketsSold>=0)
) ENGINE=INNODB;

CREATE TABLE Director(
       -- Constraint: Every Director must have an id
       id int NOT NULL,
       last varchar(20),
       first varchar(20),
       dob date,
       dod date,
       PRIMARY KEY(id),
       -- Constraint: Every Director must have a non-empty first name
       CHECK(first IS NOT NULL AND LENGTH(first)>0),
       -- Constraint: Every Director must have a dob
       CHECK(dob IS NOT NULL)
) ENGINE=INNODB;

CREATE TABLE MovieGenre(
       mid int NOT NULL,
       genre varchar(20),
       FOREIGN KEY (mid) references Movie(id)
) ENGINE=INNODB;

CREATE TABLE MovieDirector(
       mid int NOT NULL,
       did int NOT NULL,
       FOREIGN KEY (mid) references Movie(id),
       FOREIGN KEY (did) references Director(id)
) ENGINE=INNODB;

CREATE TABLE MovieActor(
       mid int NOT NULL,
       aid int NOT NULL,
       role varchar(50),
       FOREIGN KEY (mid) references Movie(id),
       FOREIGN KEY (aid) references Actor(id) 
) ENGINE=INNODB;

CREATE TABLE MovieRating(
       mid int NOT NULL,
       imdb int,
       rot int,
       FOREIGN KEY (mid) references Movie(id),
       CHECK(imdb >= 0 AND imdb <=100),
       CHECK(rot >=0 AND rot <=100)
) ENGINE=INNODB;

CREATE TABLE Review(
       name varchar(20),
       time timestamp,
       mid int NOT NULL,
       rating int,
       comment varchar(500),
       FOREIGN KEY (mid) references Movie(id)
) ENGINE=INNODB;

CREATE TABLE MaxPersonID(
       id int NOT NULL
) ENGINE=INNODB;

CREATE TABLE MaxMovieID(
       id int NOT NULL
) ENGINE=INNODB;
