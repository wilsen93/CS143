Name: Wilsen Kosasih
ID: 604501335

Primary Key Constraints
1) Movie's id
2) Actor's id
3) Director's id
Referential Integrity Constraints
1) Sales' mid References to Movie's id
2) MovieGenre's mid References to Movie's id
3) MovieDirector' mid References to Movie's id
4) MovieDirector' did Rererences to Director's id
5) MovieActor's mid References to Movie's id
6) MovieActor's aid References to Actor's id
7) MovieRating's mid References to Movie's id
8) Revie's mid References to Movie's id
CHECK constraints
1) Every Movie must have a title
2) Every Actor and Director must have a first name
3) Sales ticket cannot be negative
