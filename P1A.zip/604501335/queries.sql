-- The names of all the actors in the movie 'Die Another Day'.
SELECT CONCAT(A.first, ' ', A.last)
FROM Actor A, Movie M, MovieActor MA
WHERE A.id=MA.aid AND M.id=MA.mid AND M.title='Die Another Day';

-- The count of all the actors who acted in multiple movies.
SELECT COUNT(DISTINCT ma1.aid)
FROM MovieActor ma1, MovieActor ma2
WHERE ma1.aid=ma2.aid AND ma1.mid <> ma2.mid;

-- The title of movies that sell more than 1,000,000 tickets.
SELECT m.title
FROM Sales s, Movie m
WHERE m.id=s.mid AND s.ticketsSold>1000000;

-- Actors that have starred in a movie that has 95 or more rating by IMDb
-- and rotten tomato 
SELECT DISTINCT CONCAT(A.first, ' ', A.last)
FROM Actor A, MovieActor MA, MovieRating MR
WHERE A.id=MA.aid AND MA.mid=MR.mid AND MR.imdb>=95 AND MR.rot>=95;

-- Count the numbers of drama movies that sells more than 1,000,000 tickets
SELECT COUNT(DISTINCT mg.mid)
FROM MovieGenre mg, Sales s
WHERE mg.mid=s.mid AND mg.genre='Drama' AND s.ticketsSold>1000000;
