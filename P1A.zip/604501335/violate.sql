-- Constraint: Primary Key, Movie
INSERT INTO Movie
Values(1,'Agus',2015,'PG-13','None');
-- ERROR: Duplicate Entry for Primary Key

-- Constraint: Primary Key, Actor
INSERT INTO Actor
Values(1,'Agus',NULL,'Male',NULL,NULL);
-- ERROR: Duplicate Entry for Primary KEY

-- Constraint: Primary Key, Director
INSERT INTO Director
Values(1,'Agus',NULL, NULL, NULL);
-- ERROR: Duplicate Entry for Primary KEY

-- Constraint: Sales mid Reference Movie id
INSERT INTO Sales
Values(5111, 0, NULL);
-- Cannot add or update a child row: a foreign constraint fails

-- Constraint: MovieGenre's mid Reference Movie id
INSERT INTO MovieGenre
VALUES(5112, 'PG-13');
-- Cannot add or update a child row: a foreign contraint fails

-- Constrain: MovieDirector mid Reference Movie id
INSERT INTO MovieDirector
VALUES(5112, 1);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: MovieDirector did Reference Director id
INSERT INTO MovieDirector
VALUES(1, 1000000);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: MovieActor mid Reference Movie id
INSERT INTO MovieActor
VALUES(5112, 1, NULL);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: MovieActor aid Reference Actor id
INSERT INTO MovieActor
VALUES(1, 1000000, NULL);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: MovieRating mid Reference Movie id
INSERT INTO MovieRating
VALUES(5112, 1, 1);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: MovieRating mid Reference Movie id
INSERT INTO Review
VALUES('Agus', NULL, 5112, 1, NULL);
-- Cannot add or update a child row: a foreign constraint fails

-- Constrain: Every Actor must have a first name
INSERT INTO Actor 
VALUES(1000000, '', 'Mili', 'Male', NULL, NULL);

-- Constrain: Every Movie must have a title
INSERT INTO Movie
Values(100000, '', 2015, 'PG-13', NULL);

-- Constraint: TicketSales cannot be negative
INSERT INTO Sale
Values(1,-20,NULL);
